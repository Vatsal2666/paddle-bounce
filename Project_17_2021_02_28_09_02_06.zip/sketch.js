var ball,img,paddle;
function preload() {
  ballimage = loadImage("ball.png");
  paddleimage = loadImage("paddle.png");
}
function setup() {
  createCanvas(400, 400);
   paddle = createSprite(380,200,40,20);
   paddle.addAnimation("playerPaddle", paddleimage);
  
  ball = createSprite(200,200,10, 10);
  ball.addAnimation("ball", ballimage);
  ball.velocityX = 9;
  
 
  

}

function draw() {
  background(205,153,0);

   edges = createEdgeSprites();
  ball.bounceOff(edges[0]);
  //ball.bounceOff(edges[0]);
  

   ball.bounceOff(paddle);
   
  
  
  /* Also assign a collision callback function, so that the ball can have a random y velocity, making the game interesting */
 
  /* Prevent the paddle from going out of the edges */ 
  
  
  if(keyDown(UP_ARROW))
  {
    paddle.y = paddle.y -20;
  }
  
  if(keyDown(DOWN_ARROW))
  {
     paddle.y = paddle.y +20;
  }
  drawSprites();
  
}

function randomVelocity()
{
  /* this function gets called when the ball bounces off the paddle */
  /* assign the ball a random vertical velocity, so it bounces off in random direction */
}

